using System;

public class Program      //DO NOT change the class name
{
    static void Main()
    {
        sbyte number=125;
        Console.WriteLine("Value of number: "+number);
        Console.WriteLine("Largest value stored in a signed byte : "+sbyte.MaxValue);
    }
}
