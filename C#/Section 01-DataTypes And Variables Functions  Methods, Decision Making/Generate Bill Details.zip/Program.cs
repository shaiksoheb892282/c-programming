using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals2  //DO NOT change the namespace name
{
    public class Program      //DO NOT change the class name
    {
        public static void Main(string[] args)     //DO NOT change the 'Main' method signature
        {
            int pizzas,puffs,pepsi;
            Console.WriteLine("Enter the number of pizzas bought : ");
            pizzas=Convert.ToInt32(Console.ReadLine())*200;
            
            Console.WriteLine("Enter the number of puffs bought : ");
            puffs=Convert.ToInt32(Console.ReadLine())*40;
            
            Console.WriteLine("Enter the number of pepsi bought : ");
            pepsi=Convert.ToInt32(Console.ReadLine())*120;
            
            int total=pizzas+puffs+pepsi;
            
            double gst= ((total*12)/100);
            double cess=((total*5)/100);
            //total=total+gst+cess;
            Console.WriteLine("Bill Details");
            Console.WriteLine("Cost of Pizzas: "+pizzas);
            Console.WriteLine("Cost of Puffs: "+puffs);
            Console.WriteLine("Cost of Pepsis: "+pepsi);
            Console.WriteLine("GST 12%: "+gst);
            Console.WriteLine("CESS 5%: "+cess);
            Console.WriteLine("Total Price:"+total);
            //Implement the code here
        }
    }
}
