using System;

public class Program      //DO NOT change the class name
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter name");
        string name=Console.ReadLine();
        
        Console.WriteLine("Enter age(completed years and months)");
        double age=Convert.ToDouble(Console.ReadLine());
        
        Console.WriteLine("Enter gender('M' for Male and 'F' for Female)");
        char gender=Convert.ToChar(Console.ReadLine());
        
        Console.WriteLine("Enter city");
        string city=Console.ReadLine();
        
        Console.WriteLine("Enter mobile number");
        string mobile=Console.ReadLine();
        
        Console.WriteLine("Enter pincode");
        int pincode=Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("Name: "+name);
        Console.WriteLine("Age: "+age);
        Console.WriteLine("Gender: "+gender);
        Console.WriteLine("City: "+city);
        Console.WriteLine("Mobile: "+mobile);
        Console.WriteLine("Pincode: "+pincode);
    }
}
