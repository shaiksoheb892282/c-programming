using System;

public class Program      //DO NOT change the class name
{
    static void Main(String[] args)
    {
        int x,y;
        Console.WriteLine("Enter the value for x");
        x=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the value for y");
        y=Convert.ToInt32(Console.ReadLine());
        bool result = x < y ? true : false ;
        Console.WriteLine("x is less than y is " + result);
    }
    //implement code here
}
