using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods2               //DO NOT Change namespace name
{
    public class Program                //DO NOT Change class 'Program' name
    {
        public static void Main(string[] args)        //DO NOT Change 'Main' method Signature
        {
            Console.WriteLine("Enter a Number");
            double n=Convert.ToDouble(Console.ReadLine());
            double cube=FindCube(n);
            double square=FindSquare(n);
            Console.Write("Square of {0} is {1}" ,n, square);
            Console.Write("Cube of {0} is {1}" ,n, cube);
            Console.ReadKey();
            //Implement your code here
        }
      //Implement methods here. Keep the method 'public' and 'static'
        public static double FindCube(double n)
        {
            return n*n*n;
        }
        public static double FindSquare(double n)
        {
            return n*n;
        }

    }
}
