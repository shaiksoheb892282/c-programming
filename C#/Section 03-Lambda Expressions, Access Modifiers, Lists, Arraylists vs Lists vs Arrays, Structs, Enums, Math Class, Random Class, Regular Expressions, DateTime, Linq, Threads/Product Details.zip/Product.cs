using System;
using System.Collections.Generic;
using System.Text;

public class Product
{
    public string _productName;
    public string _serialNumber;
    public DateTime _purchaseDate;
    public double _cost;

    public Product()
    {

    }

    // Implement 4-Argument Constructor
    public Product(string productName, string serialNumber, DateTime purchaseDate, double cost)
    {
        ProductName = productName;
        SerialNumber = serialNumber;
        PurchaseDate = purchaseDate;
        Cost = cost;
    }


    // Implement Properties

    public string ProductName { get => _productName; set => _productName = value; }
    public string SerialNumber { get => _serialNumber; set => _serialNumber = value; }
    public DateTime PurchaseDate { get => _purchaseDate; set => _purchaseDate = value; }
    public double Cost { get => _cost; set => _cost = value; }

    public override string ToString()
    {
        return String.Format("{0,-15}{1,-15}{2,-15}{3,-15}", ProductName, SerialNumber, String.Format("{0:dd-MM-yyyy}", PurchaseDate), Cost);
    }
}




