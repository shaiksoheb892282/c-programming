using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;


public class Program  //DO NOT CHANGE the name of class 'Program'
{
    public static void Main(string[] args) //DO NOT CHANGE 'Main' Signature
    {

        //Fill the code here
        //IList<Product> products = new List<Product>();
        ArrayList products = new ArrayList();

        using (StreamReader reader = new StreamReader("input.csv"))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                Product product = new Product();
                product.ProductName = line.Split(',')[0].Trim();
                product.SerialNumber = line.Split(',')[1].Trim();
                product.PurchaseDate = DateTime.ParseExact(line.Split(',')[2].Trim(), "dd-MM-yyyy", CultureInfo.InvariantCulture);
                product.Cost = Convert.ToDouble(line.Split(',')[3]);
                products.Add(product);
            }
        }

        foreach (Product product in products)
        {
            Console.WriteLine(product.ToString());
        }   
    }
}