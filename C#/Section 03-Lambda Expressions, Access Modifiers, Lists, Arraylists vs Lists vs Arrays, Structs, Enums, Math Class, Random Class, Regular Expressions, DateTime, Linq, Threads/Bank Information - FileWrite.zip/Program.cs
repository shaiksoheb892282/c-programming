using System;
using System.IO;
using System.Collections;

public class Program  //DO NOT CHANGE the name of class 'Program'
{ 
   public static void Main(string[] args) //DO NOT CHANGE 'Main' Signature
   {
        string filePath=@"output.csv";
        Console.Write("Enter Account No : ");
        string accountNo=Console.ReadLine();
        Console.Write("Enter Account Holder Name : ");
        string accountHolder=Console.ReadLine();
        Console.Write("Enter Bank Name : ");
        string bankName=Console.ReadLine();
        Console.Write("Enter Bank Balance:");
        string bankBalance=Console.ReadLine();
        string fileData=accountNo+","+accountHolder+","+bankName+","+bankBalance;
        using(FileStream fs=new FileStream(filePath,FileMode.Append,FileAccess.Write))
        {
            using(StreamWriter sw=new StreamWriter(fs))
            {
                sw.WriteLine(fileData);
                sw.Flush();
                Console.WriteLine("Bank Information written to file successfully.");
            }
        }
        //WriteDataToFile(filePath,fileData);
        //File.WriteAllText("output.csv",string.Format("{0},{1},{2},{3}",accountNo,accountHolder,bankName,bankBalance));  
    }
}