
using System;
using System.Collections.Generic;

namespace BallsBowled        //DO NOT change the namespace name
{
    public class Program    //DO NOT change the class name
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of overs");  
            int oversBowled = Convert.ToInt32(Console.ReadLine());
            PlayerBO a = new PlayerBO();
            a.AddOversDetails(oversBowled);
        }
   }

    public class PlayerBO      //DO NOT change the class name
    {
     int b;
       public List<int> PlayerList { get; set; } = new List<int>();

        public void AddOversDetails(int oversBowled)       //DO NOT change the method signature
        {
            PlayerList.Add(oversBowled);
            foreach(int i in PlayerList)
            {
                b=i;
            }
            Console.WriteLine("Balls Bowled : "+GetNoOfBallsBowled());
        }

        public int GetNoOfBallsBowled()              //DO NOT change the method signature
        {
            int result = b*6;
            return result;
        }


    }
}