using System;
using System.IO;

public class Person
{
    private string firstName,lastName;
    private DateTime dob;
    public string FirstName
    {
        get{return firstName;}
        set{firstName=value;}
    }
   public string LastName
    {
        get{return lastName;}
        set{lastName=value;}
    }
    public DateTime Dob
    {
        get{return dob;}
        set{dob=value;}        
    }
    public string Adult
    {
        get
        {
            if(GetAge(dob)>=18)
            {
                return "Adult";
            }
            else
            {
                return "Child";
            }
        }
    }
    public void DisplayDetails()
    {
        Console.WriteLine("First Name: "+firstName);
        Console.WriteLine("Last Name: "+lastName);
        Console.WriteLine("Age: "+GetAge(dob));
        Console.WriteLine(Adult);
    }
    public int GetAge(DateTime dob)
    {
        DateTime d=DateTime.Now;
        int age=d.Year-dob.Year;
        if(d.DayOfYear<dob.DayOfYear)
        age-=1;
        return age;
    }
}

public class Progarm
{
    public static void Main(String[] args)
    {
        Person p=new Person();
        Console.WriteLine("Enter first name");
        p.FirstName=Console.ReadLine();
        
        Console.WriteLine("Enter last name");
        p.LastName=Console.ReadLine();
        
        Console.WriteLine("Enter date of birth in yyyy/mm/dd/ format");
        p.Dob=Convert.ToDateTime(Console.ReadLine());
        
        p.DisplayDetails();
        
    }
}
