using System;

public class Program      //DO NOT change the class name
{
    static void reverse(char []str, int start, int end) 
    {

        char temp;
        while (start <= end) 
        {
            temp = str[start];
            str[start] = str[end];
            str[end] = temp;
            start++;
            end--;
        }
    }
    static void Main(string[] args)
    {
        Console.WriteLine("Enter a string");
        string str=Console.ReadLine();
        char[] s=str.ToCharArray();

        int start = 0;
        for (int end = 0; end < s.Length; end++) 
        {
            if (s[end] == ' ') 
            {
                reverse(s, start, end-1);
                start = end + 1;
            }
        }
        
        reverse(s, start, s.Length - 1);
        reverse(s, 0, s.Length - 1);
        Console.WriteLine(s);
        Console.ReadKey();
    }
}
