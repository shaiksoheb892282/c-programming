using System;

public class Program      //DO NOT change the class name
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the number:");
        int n=Convert.ToInt32(Console.ReadLine());
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=10;j++)
            {
                Console.Write((i*j)+" ");
            }
            Console.Write("\n");
        }
    }
}
