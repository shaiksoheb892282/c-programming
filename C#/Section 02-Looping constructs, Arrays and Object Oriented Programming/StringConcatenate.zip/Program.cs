using System;

public class Program      //DO NOT change the class name
{
    static void Main(String[] args)
    {
        Console.WriteLine("Enter first name");
        String fullname=Console.ReadLine();
        Console.WriteLine("Enter last name");
        fullname+=" "+Console.ReadLine();
        Console.WriteLine("Full name : "+fullname);
    }
}
