using System;


namespace JaggedArray      //DO NOT Change the namespace name
{
    public class Program    //DO NOT Change the class name
    {
        public static void Main(string[] args)    //DO NOT change the method signature
        {
            Console.WriteLine("Enter the number of teams:");
            int m=Convert.ToInt32(Console.ReadLine());
            int[][] arr=new int[m][];
            for (int i=0; i<m;i++)
            {
                Console.WriteLine("No.of attempts for team {0}:",i+1);
                arr[i]=new int[Convert.ToInt32(Console.ReadLine())];
            }
            for (int i=0;i<m;i++)
            {
                Console.WriteLine("Enter the score for team {0}:",i+1);
                for(int j=0;j<arr[i].Length;j++)
                {
                    arr[i][j]=Convert.ToInt32(Console.ReadLine());
                }
            }
            
            string str=GetTotalScore(arr);
            Console.WriteLine(str);
            Console.ReadKey();
            //String GetTotalScore(arr[][]);
	        //Implement code here
	        // Get input from the user and construct a jagged array 
        }
        
        public static String GetTotalScore(int[][] arr)        //DO NOT change the method signature
        {
            string str="";
            
            for (int i=0;i<arr.Length;i++)
            {
                int sum=0;
                for(int j=0;j<arr[i].Length;j++)
                {
                    sum+=arr[i][j];
                }
                str+="Team "+(i+1)+" Total Score is "+sum+" . ";
            }
            return str;
            //Implement code here 
            //Method to calculate total score for each team and return a string as specified in the sample output.
        }

    }
}
