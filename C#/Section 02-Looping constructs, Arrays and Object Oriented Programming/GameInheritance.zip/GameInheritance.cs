using System;

public class Game
{
    public string Name {get; set;}
    public int MaxNumPlayers {get; set;}
    
    public override string ToString()
    {
        return ("Maximum number of players for " + Name + " is " + MaxNumPlayers);
    }
}

public class GameWithTimeLimit : Game
{
    public int TimeLimit {get; set;}
    
    public override string ToString()
    {
        Console.WriteLine(base.ToString());
        return ("Time Limit for " + Name + " is " + TimeLimit + " minutes");
    }
}

public class Program
{
    static void Main(string[] args)
    {
        Game g = new Game();
        GameWithTimeLimit tl = new GameWithTimeLimit();
        int time_limit, max_player_1, max_player_2; 
        string game_1, game_2;
        
        Console.WriteLine("Enter a game");
        game_1 = Console.ReadLine();
        Console.WriteLine("Enter the maximum number of players");
        max_player_1 = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("Enter a game that has time limit");
        game_2 = Console.ReadLine();
        Console.WriteLine("Enter the maximum number of players");
        max_player_2 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the time limit in minutes");
        time_limit = Convert.ToInt32(Console.ReadLine());
        
        g.Name = game_1;
        g.MaxNumPlayers = max_player_1;
        Console.WriteLine(g.ToString());
        
        tl.Name = game_2;
        tl.MaxNumPlayers = max_player_2;
        tl.TimeLimit = time_limit;
        Console.WriteLine(tl.ToString());
    }
}