
using System;
public class Account
{
    private int id;
    private string accountType;
    private double balance;

    public int Id
    {
        get{ return id;}
        set{ id = value;}
    }
    
    public string AccountType
    {
        get{ return accountType;}
        set{ accountType = value;}
    }
    public double Balance
    {
        get{ return balance;}
        set{ balance = value;}
    }
    public Account(){}
    public Account(int id,string accountType,double balance)
    {
        this.id=id;
        this.accountType=accountType;
        this.balance=balance;
    }
    public bool WithDraw(double amount)
    {
        if(balance>amount)
        {
            balance -= amount;
            return true;
        }
        return false;
    }
    public String GetDetails()
    {
        return ("Account Id: " + id + "\nAccount Type: " + accountType + "\nBalance: "+balance);
    }
    public static void Main(string[] args)
    {
        Account a=new Account();
        
        Console.WriteLine("Enter account id");
        a.Id=Convert.ToInt32(Console.ReadLine());
            
        Console.WriteLine("Enter account type");
        a.AccountType=Console.ReadLine();
        
        Console.WriteLine("Enter account balance");
        a.Balance=double.Parse(Console.ReadLine());
            
        Console.WriteLine("Enter amount to withdraw");
        double amount=double.Parse(Console.ReadLine());
        
        //a = new Account(id, accountType, balance);
        Console.WriteLine(a.GetDetails());
        if(a.WithDraw(amount))
        {
            Console.WriteLine("New Balance : "+a.balance);
        }
    }
}
