using System;
public class Calculator
{
    public int Addition(int a, int b)
    {
        return a+b;
    }
    
    public int Subtraction(int a, int b)
    {
        return a-b;
    }
    
    public int Multiplication(int a, int b)
    {
        return a*b;
    }
    
    public double Division(int a, int b, out double remainder)
    {
        remainder = a%b;
        return Convert.ToInt32(a/b);
    }    
}
public class Program
{
    static void Main(string[] args)
    {
        Calculator calc=new Calculator();
        Console.WriteLine("Enter the operator");
        char c=Console.ReadLine()[0];
        //double remainder;
        
        Console.WriteLine("Enter the operands");
        int a=Convert.ToInt32(Console.ReadLine());
        int b=Convert.ToInt32(Console.ReadLine());
        
        switch(c)
        {
            case '+':
                Console.WriteLine("Result of {0} + {1} is {2}",a,b,calc.Addition(a,b));
                break;
            case '-':
                Console.WriteLine("Result of {0} - {1} is {2}",a,b,calc.Subtraction(a,b));
                break;
            case '*':
                Console.WriteLine("Result of {0} * {1} is {2}",a,b,calc.Multiplication(a,b));
                break;
            case '/':
                double remainder;
                Console.WriteLine("Result of " + a + c + b + " is " + calc.Division(a,b,out remainder));
                Console.WriteLine("Remainder =" + remainder);
                break;
            default:
                Console.WriteLine("Invalid Operator");
                break;
        }
    }
}