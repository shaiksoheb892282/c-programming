using System;
public interface IOpenable
{
    string OpenSesame();
}
public class TreasureBox : IOpenable
{
    public string OpenSesame()
    {
        return "Congratulations , Here is your lucky win";
    }
}
public class Parachute : IOpenable
{
    public string OpenSesame()
    {
        return "Have a thrilling experience flying in air";
    }
}
public class Program
{
    public static void Main(string[] args)
    {
        Parachute p=new Parachute();
        TreasureBox t=new TreasureBox();
        Console.WriteLine("Enter the letter found in the paper");
        string s=Console.ReadLine();
        if(s[0]=='T')
            Console.WriteLine(t.OpenSesame());
        else
            Console.WriteLine(p.OpenSesame());
    }
}
