using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkShopEnrollmentApp
{
   public class TraineeBO
     {
         public long TraineeId {get;set;}
         public string TraineeName {get;set;}
         public string BatchCode {get;set;}
         
         public TraineeBO()
         {
         
         }
         public TraineeBO(long TraineeId, string TraineeName, string BatchCode)
         {
             this.TraineeId = TraineeId;
             this.TraineeName = TraineeName;
             this.BatchCode = BatchCode;
         }

     }
}
