using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkShopEnrollmentApp
{
     public  class TraineeBL
   {
       public bool SaveTraineeDetails(TraineeBO objBO)
       {
           
               TraineeDA td = new TraineeDA();
               bool res = td.AddTraineeDetails(objBO);
               if(res)
               {
                   return true;
               }
               else
               {
                   return false;
               }
       }
   }
}

     
     
     
     