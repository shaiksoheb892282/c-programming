using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeminarTicketBooking  //DO NOT change the namespace name
{
    public class Program   //DO NOT change the class name
    {
        public static void Main(string[] args)
        {
            bool showMenu = true;
            while (showMenu)
            {
                showMenu = MainMenu();
            }
        }

        private static bool MainMenu()
        {
            int input = 0;
            string name; string seatno;
            
            Program pgm = new Program();
            
            Console.WriteLine("Seminar Ticket Booking");
            Console.WriteLine("1. New Booking");
            Console.WriteLine("2. View All Booking");
            Console.WriteLine("3. Update Booking");
            Console.WriteLine("4. Exit");
            input = Convert.ToInt32(Console.ReadLine());

            if (input == 4)
            {	 	  	  		   	     	      	  	 	
                return false;
            }

            if (input == 1)
            {
                Console.WriteLine("Booking Name : ");
                name = Console.ReadLine();

                Console.WriteLine("Seat No. : ");
                seatno = Console.ReadLine();

                pgm.NewBooking(name, seatno);
            }
            if (input == 2)
            {
                pgm.GetAllBooking();
            }
            else if (input == 3)
            {
                Console.WriteLine("Booking Name : ");
                name = Console.ReadLine();

                Console.WriteLine("Seat No. : ");
                seatno = Console.ReadLine();

                pgm.UpdateBooking(name, seatno);
            }
           

            Console.WriteLine();
            return true;
        }
        
        public void GetAllBooking()  //DO NOT change method signature
        {
            //Fill your code here
            
              string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd=new SqlCommand("select name,seatno from booking",con);
            con.Open();
             SqlDataReader rd =  cmd.ExecuteReader();
         

           
            while (rd.Read())
            {
                 Console.WriteLine("\t{0}\t{1}",
                        rd[0], rd[1]);
                
            }
            con.Close();
        }    
        public void NewBooking(string name, string seatno)  //DO NOT change method signature
        {
            //Fill Code here
             string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
              SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("insert into Booking values(@name,@seatno)",con);
             // cmd.Connection = con;
           // cmd.CommandText = "insert into Booking values(@name,@seatno)";
            cmd.Parameters.AddWithValue("@name",name);
            cmd.Parameters.AddWithValue("@seatno", seatno);
            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected>0)
            {
                Console.WriteLine("Inserted successfully");
            }
            else
            {
                Console.WriteLine("Insertion failed");
            }
            con.Close();
        }
        public void UpdateBooking(string name, string seatno)   //DO NOT change method signature
        {
            //Fill Code here
            string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
             cmd.CommandText = "update Booking set name=@n where seatno=@seatno";
            cmd.Parameters.AddWithValue("@seatno", seatno);
            cmd.Parameters.AddWithValue("@n", name);
            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                Console.WriteLine("Updated successfully");
            }
            else
            {
                Console.WriteLine("Updation failed");
            }
            con.Close();
            
           
        }
}
}